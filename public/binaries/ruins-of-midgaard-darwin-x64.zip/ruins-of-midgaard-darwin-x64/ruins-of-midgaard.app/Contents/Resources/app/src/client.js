const nl2br = require('nl2br');
const { server, wsEvents } = require('./constants');

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1)
}

class Client {
  constructor(host, port, mainLog) {
    this.ws = new WebSocket('ws://' + host + ':' + port);
    this.mainLog = mainLog;
    this.ws.addEventListener(wsEvents.MESSAGE, (message) => this.onMessage(message))
  }
  social(channel, message) {
    this.send({ request: 'social', channel, message })
  }
  addInputFromUser(input) {
    // this.send({ request: 'input', input })
    // hack all input as social in order to dev/test
    this.request(input)
  }
  request(request) {
    this.send({ request })
  }
  send(data) {
    this.ws.send(JSON.stringify(data))
  }
  onMessage(message) {
    const data = JSON.parse(message.data)
    console.log(data)
    if (data.room) {
      const r = data.room
      this.mainLog(
        "<p>" + r.name + "</p><p>" + r.description + "</p><p>Exits: [" + ["north", "south", "east", "west", "up", "down"].map((direction) => 
          r.exits.find((exit) => exit.direction === direction) ? direction.substr(0, 1) : "").join("") + "]</p>"
          + r.inventory.items.map((item) => item.name + " is here.<br />").join("")
          + (r.inventory.items.length > 0 ? "<br />" : "")
          + r.mobs.filter((mob) => mob.name !== this.player.sessionMob.name).map((mob) => capitalizeFirstLetter(mob.name) + " is here.<br />").join("")
      )
      return
    }

    if (data.inventory) {
      const i = data.inventory
      this.mainLog(
        "<p>Your inventory:</p>" + i.items.map((item) => "<p>" + item.name + "</p>").join("")
      )
      return
    }

    if (data.mob || data.item) {
      const thing = data.mob ? data.mob : data.item
      this.mainLog(
        "<p>" + thing.description + "</p>"
      )
      return
    }

    if (data.player) {
      this.player = data.player
      return
    }

    if (data.message) {
      this.mainLog("<p>" + nl2br(data.message) + "</p>")
    }
  }
  onClose() {
    this.ws.close()
  }
}

module.exports = {
    Client
};
